package com.cloudbees.trainapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainAppApplication.class, args);
	}

}
